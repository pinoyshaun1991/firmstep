<?php
namespace Queue\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Queue\Model\Queue;
use Queue\Form\QueueForm;
use Zend\View\Model\JsonModel;

class QueueController extends AbstractActionController
{
    protected $queueTable;
    protected $serviceTable;

    public function indexAction()
    {
        $form = new QueueForm();
        $form->get('submit')->setValue('Submit');
        $request = $this->getRequest();
        if ($request->isPost()) {
            $queue = new Queue();
            $form->setInputFilter($queue->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $this->addAction($form->getData(), $queue);
            }
        }

        return new ViewModel(array(
            'queues' => $this->getQueueTable()->fetchAll(),
            'services' => $this->getServiceTable()->fetchAll(),
            'form' => $form
        ));
    }

    public function addAction($params = array(), $queue = null)
    {
        if (isset($params)) {
            $queue->exchangeArray($params);
            $this->getQueueTable()->saveQueue($queue);
        }
        // Redirect to list of queues
        return $this->redirect()->toRoute('queue');
    }

    public function searchAction()
    {
        $request = $this->getRequest();

        if ($request->isXmlHttpRequest()){ // If it's ajax call
            $serviceParam = $request->getPost('service');
            $dataSet = $this->getQueueTable()->select(array('service' => $serviceParam));
            if (count($dataSet) > 0) {
                http_response_code(200);
                foreach ($dataSet as $data) {
                    $response = array('data' => $data);
                }
            } else {
                http_response_code(402);
                $response = array('code' => 402, 'message' => 'Could not find the following service id: '.$serviceParam);
            }
        }

        $data = new JsonModel($response);

        return $data;

    }

    public function serveAction()
    {
        $request = $this->getRequest();

        if ($request->isXmlHttpRequest()){ // If it's ajax call
            $customerId = $request->getPost('customerId');

            // Get the Queue with the specified id.  An exception is thrown
            // if it cannot be found, in which case go to the index page.
            try {
                $customer = $this->getQueueTable()->getQueue($customerId);
            }
            catch (\Exception $ex) {
                return $this->redirect()->toRoute('queue', array(
                    'action' => 'index'
                ));
            }
            $dataSet = $this->getQueueTable()->saveQueue($customer, $isServed = true);

            if ($dataSet === true) {
                http_response_code(200);
                $response = array('code' => 200, 'message' => 'Served customer id: '.$customerId);
            } else {
                http_response_code(402);
                $response = array('code' => 402, 'message' => 'Could not find the following customer: '.$customerId);
            }
        }

        $data = new JsonModel($response);

        return $data;

    }

    public function forwardAction()
    {
        $request = $this->getRequest();

        if ($request->isXmlHttpRequest()){ // If it's ajax call
            $customerId = $request->getPost('customerId');

            // Get the Queue with the specified id.  An exception is thrown
            // if it cannot be found, in which case go to the index page.
            try {
                $customer = $this->getQueueTable()->getQueue($customerId);
            }
            catch (\Exception $ex) {
                return $this->redirect()->toRoute('queue', array(
                    'action' => 'index'
                ));
            }
            $dataSet = $this->getQueueTable()->saveQueue($customer, $isServed = false, $isForward = true);

            if ($dataSet === true) {
                http_response_code(200);
                $response = array('code' => 200, 'message' => 'Served customer id: '.$customerId);
            } else {
                http_response_code(402);
                $response = array('code' => 402, 'message' => 'Could not find the following customer: '.$customerId);
            }
        }

        $data = new JsonModel($response);

        return $data;

    }

    public function getQueueTable()
    {
        if (!$this->queueTable) {
            $sm = $this->getServiceLocator();
            $this->queueTable = $sm->get('Queue\Model\QueueTable');
        }
        return $this->queueTable;
    }

    public function getServiceTable()
    {
        if (!$this->serviceTable) {
            $sm = $this->getServiceLocator();
            $this->serviceTable = $sm->get('Queue\Model\ServiceTable');
        }
        return $this->serviceTable;
    }
}