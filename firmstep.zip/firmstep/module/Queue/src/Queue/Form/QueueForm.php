<?php

namespace Queue\Form;

use Zend\Form\Form;

class QueueForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('queue');

        $this->add(array(
            'name' => 'id',
            'type' => 'Hidden',
        ));

        $this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'title',
            'options' => array(
                'label' => 'Title',
                'value_options' => array(
                    'Mr.' => 'Mr.',
                    'Mrs.' => 'Mrs.',
                    'Miss.' => 'Miss',
                ),
                'label_attributes' => array(
                    'class' => 'citizen',
                ),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'firstName',
            'type' => 'Text',
            'options' => array(
                'label' => 'First Name',
                'label_attributes' => array(
                    'class' => 'citizen',
                ),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'lastName',
            'type' => 'Text',
            'options' => array(
                'label' => 'Last Name',
                'label_attributes' => array(
                    'class' => 'citizen',
                ),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'organisation',
            'type' => 'Text',
            'options' => array(
                'label' => 'Organisation Name',
                'label_attributes' => array(
                    'class' => 'organisation',
                ),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'type',
        ));

        $this->add(array(
            'name' => 'service',
        ));

        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitButton',
                'class' => 'btn btn-primary',
            ),
        ));
    }
}