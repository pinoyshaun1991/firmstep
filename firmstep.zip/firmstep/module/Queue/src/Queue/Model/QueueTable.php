<?php
namespace Queue\Model;

use Zend\Db\TableGateway\TableGateway;

class QueueTable
{
    protected $tableGateway;

    /**
     * QueueTable constructor.
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * @return null|\Zend\Db\ResultSet\ResultSetInterface
     */
    public function fetchAll()
    {
        $sqlSelect = $this->tableGateway->getSql()->select()->columns(array(
            'id' => 'id',
            'type' => 'type',
            'title' => 'title',
            'firstName' => 'first_name',
            'lastName' => 'last_name',
            'quedAt' => 'qued_at',
            'organisation' => 'organisation',
        ))
            ->join('services', 'services.id = customers.service', array('serviceName' => 'name'))
            ->where(array('is_served' => 0))
            ->order('is_forward', 'DESC');

        $resultSet = $this->tableGateway->selectWith($sqlSelect);

        return $resultSet;
    }

    /**
     * @param array $params
     * @return null|\Zend\Db\ResultSet\ResultSetInterface
     */
    public function select($params = array())
    {

        $sqlSelect = $this->tableGateway->getSql()->select()->columns(array(
            'id' => 'id',
            'type' => 'type',
            'title' => 'title',
            'firstName' => 'first_name',
            'lastName' => 'last_name',
            'quedAt' => 'qued_at',
            'organisation' => 'organisation',
        ))
            ->join('services', 'services.id = customers.service', array('serviceName' => 'name'))
            ->where($params)
            ->where(array('is_served' => 0));

        $resultSet = $this->tableGateway->selectWith($sqlSelect);

        return $resultSet;
    }

    /**
     * @param array $params
     * @return mixed
     */
    public function updateServe($params = array())
    {
        return $this->tableGateway->getSql()->update()->columns(array('is_served' => 1))->where($params);
    }

    /**
     * @param $id
     * @return array|\ArrayObject|null
     * @throws \Exception
     */
    public function getQueue($id)
    {
        $id  = (int) $id;
        $rowset = $this->tableGateway->select(array('id' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }

    /**
     * @param Queue $queue
     * @param bool $isServed
     * @param bool $isForward
     * @return bool
     * @throws \Exception
     */
    public function saveQueue(Queue $queue, $isServed = false, $isForward = false)
    {
        $data = array(
            'type'  => $queue->type,
            'service'  => $queue->service,
            'title'  => $queue->title,
            'first_name'  => $queue->firstName,
            'last_name'  => $queue->lastName,
            'organisation' => $queue->organisation,
            'qued_at' => date("H:i"),
            'is_served' => $isServed === true ? 1 : 0,
            'is_forward' => $isForward === true ? 1 : 0,
        );

        $id = (int) $queue->id;
        if ($id === 0) {
            $this->tableGateway->insert($data);
        } else {
            if ($this->getQueue($id)) {
                $this->tableGateway->update($data, array('id' => $id));
            } else {
                throw new \Exception('Queue id does not exist');
            }
        }
        return true;
    }

    /**
     * @param $id
     * @return int
     */
    public function deleteQueue($id)
    {
        return $this->tableGateway->delete(array('id' => (int) $id));
    }
}