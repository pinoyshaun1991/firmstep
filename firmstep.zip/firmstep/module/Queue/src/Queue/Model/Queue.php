<?php
namespace Queue\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Queue
{
    public $id;
    public $type;
    public $firstName;
    public $lastName;
    public $title;
    public $service;
    public $organisation;
    public $serviceName;
    public $quedAt;
    public $isServed;
    public $isForward;

    /* @param $id
    * @return $this
    * Set $id variable to validate it to an integer
    */
    public function setId($id)
    {
        $idNumber = (int)$id;
        if (!(is_numeric($idNumber))) {
            throw new Exception('ID must be integer');
        }
        $this->id = $idNumber;
        return $this;
    }

    /**
     * @param $type
     * @return $this
     * Set $type variable to validate it to an string
     */
    public function setType($type)
    {
        $typeString = (string)$type;
        if (!(is_string($typeString))) {
            throw new Exception('Type must be string');
        }
        $this->type = $typeString;
        return $this;
    }

    /**
     * @param $firstName
     * @return $this
     * Set $firstName variable to validate it to an string
     */
    public function setFirstName($firstName)
    {
        $firstNameString = (string)$firstName;
        if (!(is_string($firstNameString))) {
            throw new Exception('First Name must be string');
        }
        $this->firstName = $firstNameString;
        return $this;
    }

    /**
     * @param $lastName
     * @return $this
     * Set $lastName variable to validate it to an string
     */
    public function setLastName($lastName)
    {
        $lastNameString = (string)$lastName;
        if (!(is_string($lastNameString))) {
            throw new Exception('Last Name must be string');
        }
        $this->lastName = $lastNameString;
        return $this;
    }

    /**
     * @param $title
     * @return $this
     * Set $title variable to validate it to an string
     */
    public function setTitle($title)
    {
        $titleString = (string)$title;
        if (!(is_string($titleString))) {
            throw new Exception('Title must be string');
        }
        $this->title = $titleString;
        return $this;
    }

    /**
     * @param $service
     * @return $this
     * Set $service variable to validate it to an integer
     */
    public function setService($service)
    {
        $serviceNumber = (int)$service;
        if (!(is_int($serviceNumber))) {
            throw new Exception('Service must be a number');
        }
        $this->service = $serviceNumber;
        return $this;
    }

    /**
     * @param $organisation
     * @return $this
     * Set $organisation variable to validate it to an string
     */
    public function setOrganisation($organisation)
    {
        $organisationString = (string)$organisation;
        if (!(is_string($organisationString))) {
            throw new Exception('Organisation must be string');
        }
        $this->organisation = $organisationString;
        return $this;
    }

    /**
     * @param $serviceName
     * @return $this
     * Set $title variable to validate it to an string
     */
    public function setServiceName($serviceName)
    {
        $serviceNameString = (string)$serviceName;
        if (!(is_string($serviceNameString))) {
            throw new Exception('Service Name must be string');
        }
        $this->serviceName = $serviceNameString;
        return $this;
    }

    /**
     * @param $isServed
     * @return $this
     * Set $quedAt variable to validate it to an integer
     */
    public function setIsServed($isServed)
    {
        $isServedNumber = (int)$isServed;
        if (!(is_int($isServedNumber))) {
            throw new Exception('Is Served must be a number');
        }
        $this->isServed = $isServedNumber;
        return $this;
    }

    /**
     * @param $isForward
     * @return $this
     * Set $isForward variable to validate it to an integer
     */
    public function setIsForward($isForward)
    {
        $isForwardNumber = (int)$isForward;
        if (!(is_int($isForwardNumber))) {
            throw new Exception('Is Forward must be a number');
        }
        $this->isForward = $isForwardNumber;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return mixed
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * @return mixed
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @return mixed
     */
    public function getService()
    {
        return $this->service;
    }

    /**
     * @return mixed
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }

    /**
     * @return mixed
     */
    public function getServiceName()
    {
        return $this->serviceName;
    }

    /**
     * @return mixed
     */
    public function getIsServed()
    {
        return $this->isServed;
    }

    /**
     * @return mixed
     */
    public function getIsForward()
    {
        return $this->isForward;
    }

    /**
     * @param $data
     * @throws Exception
     */
    public function exchangeArray($data)
    {
        $this->setId(isset($data['id']) && !empty(($data['id'])) ? $data['id'] : null);
        $this->setType(isset($data['type']) && !empty(($data['type'])) ? $data['type'] : null);
        $this->setFirstName(isset($data['firstName']) && !empty(($data['firstName'])) ? $data['firstName'] : null);
        $this->setLastName(isset($data['lastName']) && !empty(($data['lastName'])) ? $data['lastName'] : null);
        $this->setTitle(isset($data['title']) && !empty(($data['title'])) ? $data['title'] : null);
        $this->setService(isset($data['service']) ? $data['service'] : null);
        $this->setOrganisation(isset($data['organisation']) && !empty(($data['organisation'])) ? $data['organisation'] : null);
        $this->setServiceName(isset($data['serviceName']) && !empty(($data['serviceName'])) ? $data['serviceName'] : null);
        $this->setIsServed(isset($data['isServed']) ? $data['isServed'] : null);
        $this->setIsForward(isset($data['isForward']) ? $data['isForward'] : null);

        $this->id = $this->getId();
        $this->type = $this->getType();
        $this->firstName = $this->getFirstName();
        $this->lastName = $this->getLastName();
        $this->service = $this->getService();
        $this->serviceName = $this->getServiceName();
        $this->title = $this->getTitle();
        $this->organisation = $this->getOrganisation();
        $this->quedAt = isset($data['quedAt']) ? $data['quedAt'] : null;
        $this->isServed = $this->getIsServed();
        $this->isForward = $this->getIsForward();
    }

    /**
     * @param InputFilterInterface $inputFilter
     * @throws \Exception
     */
    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }

    /**
     * @return InputFilter
     */
    public function getInputFilter()
    {
        if (!isset($this->inputFilter)) {
            $inputFilter = new InputFilter();

            $inputFilter->add(array(
                'name'     => 'id',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
            ));

            $inputFilter->add(array(
                'name'     => 'title',
                'required' => false,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 100,
                        ),
                    ),
                ),
            ));

            $inputFilter->add(array(
                'name'     => 'firstName',
                'required' => false,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 100,
                        ),
                    ),
                ),
            ));

            $inputFilter->add(array(
                'name'     => 'lastName',
                'required' => false,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 100,
                        ),
                    ),
                ),
            ));

            $inputFilter->add(array(
                'name'     => 'organisation',
                'required' => false,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 100,
                        ),
                    ),
                ),
            ));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    /**
     * @return array
     */
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}