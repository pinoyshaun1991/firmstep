<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'Queue\Controller\Queue' => 'Queue\Controller\QueueController',
        ),
    ),

    'router' => array(
        'routes' => array(
            'queue' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/queue[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Queue\Controller\Queue',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'queue' => __DIR__ . '/../view',
        ),
        'strategies' => array(
            'ViewJsonStrategy',
        ),
    ),
);