<?php
namespace ModelTest\Model;

use Zend\Test\PHPUnit\Controller\AbstractHttpControllerTestCase;
use Queue\Model\Queue;

class QueueTest extends AbstractHttpControllerTestCase
{
    public function setUp()
    {
        $this->setApplicationConfig(
            include './config/application.config.php'
        );
        parent::setUp();
    }
    public function testIdIsInteger()
    {
        $model = new Queue();
        $model->setId(1);
        $this->assertEquals(1, $model->getId());
    }

    public function testFirstNameIsString()
    {
        $model = new Queue();
        $model->setFirstName('Test');
        $this->assertEquals('Test', $model->getFirstName());
    }

    public function testLastNameIsString()
    {
        $model = new Queue();
        $model->setLastName('Test');
        $this->assertEquals('Test', $model->getLastName());
    }

    public function testEmpty()
    {
        $stack = [];
        $this->assertEmpty($stack);

        return $stack;
    }

}