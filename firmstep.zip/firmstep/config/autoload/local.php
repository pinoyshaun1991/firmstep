<?php
return array(
    'db' => array(
        'username' => 'root',
        'password' => '',
    ),
);